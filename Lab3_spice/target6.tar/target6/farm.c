/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_497(unsigned x)
{
    return x + 2428995912U;
}

void setval_159(unsigned *p)
{
    *p = 1479650421U;
}

unsigned getval_269()
{
    return 2425362648U;
}

unsigned addval_394(unsigned x)
{
    return x + 3339274373U;
}

unsigned getval_404()
{
    return 3347662900U;
}

unsigned addval_193(unsigned x)
{
    return x + 2411944018U;
}

void setval_166(unsigned *p)
{
    *p = 3251079496U;
}

unsigned getval_208()
{
    return 415211244U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_451(unsigned *p)
{
    *p = 3285090617U;
}

unsigned getval_229()
{
    return 3223899785U;
}

unsigned addval_314(unsigned x)
{
    return x + 3229929099U;
}

unsigned getval_105()
{
    return 2447411528U;
}

unsigned addval_158(unsigned x)
{
    return x + 3281044107U;
}

unsigned getval_259()
{
    return 3223375497U;
}

void setval_211(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_186(unsigned x)
{
    return x + 2430634440U;
}

void setval_146(unsigned *p)
{
    *p = 3281044105U;
}

void setval_165(unsigned *p)
{
    *p = 2430601544U;
}

unsigned getval_112()
{
    return 3465114738U;
}

unsigned addval_198(unsigned x)
{
    return x + 3531915915U;
}

void setval_164(unsigned *p)
{
    *p = 3767094484U;
}

void setval_191(unsigned *p)
{
    *p = 3374367369U;
}

void setval_271(unsigned *p)
{
    *p = 3525366169U;
}

unsigned getval_462()
{
    return 3353381192U;
}

void setval_321(unsigned *p)
{
    *p = 3375419017U;
}

unsigned addval_447(unsigned x)
{
    return x + 3525362312U;
}

unsigned getval_297()
{
    return 3767093287U;
}

void setval_144(unsigned *p)
{
    *p = 3534013065U;
}

unsigned addval_418(unsigned x)
{
    return x + 3281179017U;
}

unsigned addval_250(unsigned x)
{
    return x + 3372798345U;
}

void setval_102(unsigned *p)
{
    *p = 3372794504U;
}

void setval_174(unsigned *p)
{
    *p = 2447411528U;
}

void setval_270(unsigned *p)
{
    *p = 3380924841U;
}

void setval_273(unsigned *p)
{
    *p = 3380924809U;
}

unsigned getval_376()
{
    return 2429452618U;
}

unsigned getval_460()
{
    return 3676885385U;
}

void setval_141(unsigned *p)
{
    *p = 3251538293U;
}

unsigned addval_181(unsigned x)
{
    return x + 2425541001U;
}

unsigned addval_143(unsigned x)
{
    return x + 3281306249U;
}

unsigned addval_318(unsigned x)
{
    return x + 3682914729U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
